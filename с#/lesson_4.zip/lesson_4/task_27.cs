using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите число: ");
        int number = Convert.ToInt32(Console.ReadLine());

        int sum = SumOfDigits(number); // Вызываем функцию SumOfDigits для подсчета суммы цифр числа

        Console.WriteLine("Сумма цифр: " + sum);

        Console.ReadLine();
    }

    static int SumOfDigits(int number) // Функция для подсчета суммы цифр числа
    {
        int sum = 0;

        while (number != 0)
        {
            int digit = number % 10; // Получаем последнюю цифру числа
            sum += digit; // Добавляем цифру к сумме
            number /= 10; // Удаляем последнюю цифру числа
        }

        return sum;
    }
}
