using System;

class Program
{
    static void Main(string[] args)
    {
        int[] numbers = { 1, 2, 5, 7, 19, 4, 76, 3 }; // Создаем массив из 8 элементов

        Console.Write("[");
        for (int i = 0; i < numbers.Length; i++)
        {
            Console.Write(numbers[i]); // Выводим элементы массива
            if (i < numbers.Length - 1)
            {
                Console.Write(", "); // Выводим запятую и пробел после каждого элемента, кроме последнего
            }
        }
        Console.WriteLine("]");

        Console.ReadLine();
    }
}
