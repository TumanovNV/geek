using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите число A: ");
        int A = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Введите число B: ");
        int B = Convert.ToInt32(Console.ReadLine());

        int result = Power(A, B); // Вызываем функцию Power для возведения числа A в степень B

        Console.WriteLine("Результат: " + result);

        Console.ReadLine();
    }

    static int Power(int baseNumber, int exponent) // Функция для возведения числа в степень
    {
        int result = 1;

        for (int i = 1; i <= exponent; i++)
        {
            result *= baseNumber;
        }

        return result;
    }
}
